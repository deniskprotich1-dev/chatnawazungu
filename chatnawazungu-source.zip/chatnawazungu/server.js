const express = require("express");
const http = require("http");
const path = require("path");
const helmet = require("helmet");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database(process.env.DB_PATH || "chatnawazungu.sqlite");
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET) {
  console.error("Set SESSION_SECRET to a long random value before starting.");
  process.exit(1);
}

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 suspended INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 body TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS reports (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 message_id INTEGER NOT NULL,
 reporter_id INTEGER NOT NULL,
 reason TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "12kb" }));
app.use(session({
  name: "cnw.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));

const cleanName = s => String(s || "").trim().replace(/[^a-zA-Z0-9_]/g, "").slice(0, 18);
const safeText = s => String(s || "").trim().slice(0, 500);
const bannedPatterns = [
  /\b\d{7,}\b/,
  /\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b/i,
  /\b(?:whatsapp|telegram|snapchat|instagram)\b/i,
  /\b(?:send me|dm me|text me)\b/i
];
function publicUser(req) {
  if (!req.session.user) return null;
  return { id: req.session.user.id, username: req.session.user.username };
}
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in first." });
  const user = db.prepare("SELECT id, username, suspended FROM users WHERE id=?").get(req.session.user.id);
  if (!user || user.suspended) {
    req.session.destroy(() => {});
    return res.status(403).json({ error: "This account cannot access the community." });
  }
  next();
}
function requireAdmin(req, res, next) {
  if (!process.env.ADMIN_USERNAME || req.session.user?.username !== process.env.ADMIN_USERNAME)
    return res.status(403).json({ error: "Moderator access only." });
  next();
}

app.get("/api/me", (req, res) => res.json({ user: publicUser(req) }));

app.post("/api/register", async (req, res) => {
  const username = cleanName(req.body.username);
  const password = String(req.body.password || "");
  if (username.length < 3) return res.status(400).json({ error: "Username must be 3–18 letters, numbers or underscores." });
  if (password.length < 12) return res.status(400).json({ error: "Use a password of at least 12 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username, hash);
    req.session.user = { id: Number(result.lastInsertRowid), username };
    res.json({ user: publicUser(req) });
  } catch {
    res.status(409).json({ error: "That username is already taken." });
  }
});

app.post("/api/login", async (req, res) => {
  const username = cleanName(req.body.username);
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || user.suspended || !(await bcrypt.compare(String(req.body.password || ""), user.password_hash)))
    return res.status(401).json({ error: "Username or password is incorrect." });
  req.session.user = { id: user.id, username: user.username };
  res.json({ user: publicUser(req) });
});

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/messages", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT messages.id, users.username, messages.body, messages.created_at
    FROM messages JOIN users ON users.id=messages.user_id
    WHERE messages.status='approved' ORDER BY messages.id DESC LIMIT 60
  `).all().reverse();
  res.json({ messages: rows });
});

app.post("/api/messages", requireAuth, (req, res) => {
  const body = safeText(req.body.body);
  if (body.length < 1) return res.status(400).json({ error: "Write a message first." });
  if (bannedPatterns.some(pattern => pattern.test(body)))
    return res.status(400).json({ error: "For safety, don't share contact details or ask people to move to private apps." });
  const result = db.prepare("INSERT INTO messages(user_id,body,status) VALUES(?,?,'pending')").run(req.session.user.id, body);
  io.to("moderators").emit("review-needed");
  res.json({ ok: true, message: "Your message was sent for moderator review.", id: Number(result.lastInsertRowid) });
});

app.post("/api/reports", requireAuth, (req, res) => {
  const messageId = Number(req.body.messageId);
  const reason = safeText(req.body.reason).slice(0, 120);
  const msg = db.prepare("SELECT id FROM messages WHERE id=? AND status='approved'").get(messageId);
  if (!msg || !reason) return res.status(400).json({ error: "Choose a message and report reason." });
  db.prepare("INSERT INTO reports(message_id,reporter_id,reason) VALUES(?,?,?)").run(messageId, req.session.user.id, reason);
  io.to("moderators").emit("review-needed");
  res.json({ ok: true });
});

app.get("/api/moderation", requireAuth, requireAdmin, (req, res) => {
  const pending = db.prepare(`
    SELECT messages.id, users.username, messages.body, messages.created_at
    FROM messages JOIN users ON users.id=messages.user_id
    WHERE messages.status='pending' ORDER BY messages.id ASC
  `).all();
  const reports = db.prepare(`
    SELECT reports.id, reports.message_id, reports.reason, users.username AS reporter
    FROM reports JOIN users ON users.id=reports.reporter_id ORDER BY reports.id DESC LIMIT 100
  `).all();
  res.json({ pending, reports });
});

app.post("/api/moderation/:id/:action", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const action = req.params.action;
  if (!["approve", "reject"].includes(action)) return res.status(400).json({ error: "Invalid action." });
  const status = action === "approve" ? "approved" : "rejected";
  db.prepare("UPDATE messages SET status=? WHERE id=?").run(status, id);
  if (status === "approved") io.emit("new-approved-message");
  res.json({ ok: true });
});

io.use((socket, next) => {
  const user = socket.request.session?.user;
  if (!user) return next(new Error("Sign in required"));
  socket.user = user;
  next();
});
const sessionMiddleware = app.get("trust proxy");
io.engine.use((req, res, next) => {
  // Express session middleware is attached below through the shared store.
  next();
});
io.on("connection", socket => {
  if (process.env.ADMIN_USERNAME && socket.user.username === process.env.ADMIN_USERNAME)
    socket.join("moderators");
  socket.on("join-community", () => socket.emit("community-ready"));
});

server.listen(PORT, () => console.log(`ChatNaWazungu running on port ${PORT}`));
