# ChatNaWazungu Community

A starter Node.js application for a moderated public language/culture-exchange community.

## Included
- Account registration and sign-in (bcrypt password hashing)
- Public community message board
- Messages held for moderator approval
- User reporting
- Moderator approval/rejection endpoint
- Basic rate limiting and security headers

## Important limitations
This is a starter application, not a fully audited production service. It deliberately does **not** include paid chat, per-minute earnings, withdrawals, payment collection, private messaging, identity verification, or automated age verification. Do not collect fees or promise earnings using this starter.

Before opening to the public, arrange a professional security/privacy review, add email verification and account recovery, stronger moderation and reporting workflows, data retention/deletion tools, backups, and a clear privacy notice and community rules. Use appropriate safeguarding and age protections for the intended audience.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Set `SESSION_SECRET` to a long random value.
4. Set `ADMIN_USERNAME` to a unique username you will register as the moderator.
5. Run `npm start`.
6. Visit `http://localhost:3000`.

The first account with the configured `ADMIN_USERNAME` can use moderator endpoints. Keep the moderator username private. For production, use a managed database and persistent disk; SQLite on ephemeral hosting storage can be lost on redeploy.

## Deploy on Render
- Create a **Web Service** from this GitHub repository.
- Build command: `npm install`
- Start command: `npm start`
- Add environment variables from `.env.example`.
- Attach a persistent disk and set `DB_PATH` to its mount path.
- Use HTTPS and verify that the app works before inviting users.

## Socket.IO note
This starter uses HTTP polling for refresh-safe community updates. For production real-time sockets, configure shared session middleware for Socket.IO and test authentication carefully before enabling websocket transport.
